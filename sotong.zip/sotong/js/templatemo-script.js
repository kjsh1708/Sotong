
    const bgImgsNames = ['squid1.jpeg'];
    const bgImgs = bgImgsNames.map(img => "img/" + img);
    $.backstretch(bgImgs);

const setBg = id => {
    $.backstretch('show', id);
}


